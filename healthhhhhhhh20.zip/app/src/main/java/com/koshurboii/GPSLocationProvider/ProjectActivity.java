package com.koshurboii.GPSLocationProvider;

import android.animation.*;
import android.app.*;
import android.content.*;
import android.content.Intent;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.regex.*;
import org.json.*;

public class ProjectActivity extends AppCompatActivity {
	
	private LinearLayout linear1;
	private LinearLayout linear5;
	private LinearLayout linear24;
	private LinearLayout linear34;
	private LinearLayout linear26;
	private LinearLayout linear40;
	private LinearLayout linear44;
	private LinearLayout linear28;
	private TextView textview1;
	private TextView textview26;
	private TextView textview13;
	private LinearLayout linear35;
	private TextView textview20;
	private LinearLayout linear33;
	private TextView textview19;
	private LinearLayout linear41;
	private TextView textview23;
	private LinearLayout linear45;
	private TextView textview25;
	
	private Intent i = new Intent();
	private Intent p = new Intent();
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.project);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		linear1 = findViewById(R.id.linear1);
		linear5 = findViewById(R.id.linear5);
		linear24 = findViewById(R.id.linear24);
		linear34 = findViewById(R.id.linear34);
		linear26 = findViewById(R.id.linear26);
		linear40 = findViewById(R.id.linear40);
		linear44 = findViewById(R.id.linear44);
		linear28 = findViewById(R.id.linear28);
		textview1 = findViewById(R.id.textview1);
		textview26 = findViewById(R.id.textview26);
		textview13 = findViewById(R.id.textview13);
		linear35 = findViewById(R.id.linear35);
		textview20 = findViewById(R.id.textview20);
		linear33 = findViewById(R.id.linear33);
		textview19 = findViewById(R.id.textview19);
		linear41 = findViewById(R.id.linear41);
		textview23 = findViewById(R.id.textview23);
		linear45 = findViewById(R.id.linear45);
		textview25 = findViewById(R.id.textview25);
		
		textview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				p.setClass(getApplicationContext(), MedicinesavailableActivity.class);
				startActivity(p);
			}
		});
		
		textview26.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				p.setClass(getApplicationContext(), WebviverActivity.class);
				startActivity(p);
			}
		});
		
		linear35.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				i.setAction(Intent.ACTION_VIEW);
				i.setData(Uri.parse("android-app://ar.com.basejuegos.simplealarm"));
				startActivity(i);
			}
		});
		
		linear33.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				i.setAction(Intent.ACTION_VIEW);
				i.setData(Uri.parse("android-app://ar.com.basejuegos.simplealarm"));
				startActivity(i);
			}
		});
		
		linear41.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				i.setAction(Intent.ACTION_VIEW);
				i.setData(Uri.parse("android-app://ar.com.basejuegos.simplealarm"));
				startActivity(i);
			}
		});
		
		linear45.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				i.setAction(Intent.ACTION_VIEW);
				i.setData(Uri.parse("android-app://ar.com.basejuegos.simplealarm"));
				startActivity(i);
			}
		});
	}
	
	private void initializeLogic() {
	}
	
}