package com.koshurboii.GPSLocationProvider;

import android.animation.*;
import android.app.*;
import android.content.*;
import android.content.Intent;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.media.SoundPool;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.regex.*;
import org.json.*;

public class NotdbActivity extends AppCompatActivity {
	
	private double aa = 0;
	private double aaa = 0;
	private double aaaa = 0;
	
	private LinearLayout linear1;
	private LinearLayout linear5;
	private LinearLayout linear6;
	private LinearLayout linear24;
	private LinearLayout linear25;
	private LinearLayout linear26;
	private LinearLayout linear27;
	private LinearLayout linear40;
	private LinearLayout linear28;
	private TextView textview1;
	private LinearLayout linear13;
	private LinearLayout linear12;
	private TextView textview13;
	private ImageView imageview2;
	private LinearLayout linear32;
	private TextView textview18;
	private ImageView imageview1;
	private LinearLayout linear33;
	private TextView textview19;
	private ImageView imageview3;
	private LinearLayout linear34;
	private TextView textview20;
	private ImageView imageview5;
	private LinearLayout linear41;
	private TextView textview23;
	
	private Intent Page = new Intent();
	private Intent i = new Intent();
	private SoundPool a;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.notdb);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		linear1 = findViewById(R.id.linear1);
		linear5 = findViewById(R.id.linear5);
		linear6 = findViewById(R.id.linear6);
		linear24 = findViewById(R.id.linear24);
		linear25 = findViewById(R.id.linear25);
		linear26 = findViewById(R.id.linear26);
		linear27 = findViewById(R.id.linear27);
		linear40 = findViewById(R.id.linear40);
		linear28 = findViewById(R.id.linear28);
		textview1 = findViewById(R.id.textview1);
		linear13 = findViewById(R.id.linear13);
		linear12 = findViewById(R.id.linear12);
		textview13 = findViewById(R.id.textview13);
		imageview2 = findViewById(R.id.imageview2);
		linear32 = findViewById(R.id.linear32);
		textview18 = findViewById(R.id.textview18);
		imageview1 = findViewById(R.id.imageview1);
		linear33 = findViewById(R.id.linear33);
		textview19 = findViewById(R.id.textview19);
		imageview3 = findViewById(R.id.imageview3);
		linear34 = findViewById(R.id.linear34);
		textview20 = findViewById(R.id.textview20);
		imageview5 = findViewById(R.id.imageview5);
		linear41 = findViewById(R.id.linear41);
		textview23 = findViewById(R.id.textview23);
		
		linear5.setOnLongClickListener(new View.OnLongClickListener() {
			@Override
			public boolean onLongClick(View _view) {
				i.setAction(Intent.ACTION_VIEW);
				i.setData(Uri.parse("android-app://chat.akash"));
				startActivity(i);
				aaaa = a.play((int)(1), 1.0f, 1.0f, 1, (int)(0), 1.0f);;
				return true;
			}
		});
		
		linear6.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				Page.setClass(getApplicationContext(), ProfilenotdbActivity.class);
				startActivity(Page);
				aaaa = a.play((int)(1), 1.0f, 1.0f, 1, (int)(0), 1.0f);;
			}
		});
		
		linear32.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				Page.setClass(getApplicationContext(), Do1Activity.class);
				startActivity(Page);
				aaaa = a.play((int)(1), 1.0f, 1.0f, 1, (int)(0), 1.0f);;
			}
		});
		
		linear33.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				Page.setClass(getApplicationContext(), Do2Activity.class);
				startActivity(Page);
				aaaa = a.play((int)(1), 1.0f, 1.0f, 1, (int)(0), 1.0f);;
			}
		});
		
		linear34.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				Page.setClass(getApplicationContext(), Do3Activity.class);
				startActivity(Page);
				aaaa = a.play((int)(1), 1.0f, 1.0f, 1, (int)(0), 1.0f);;
			}
		});
		
		linear41.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				Page.setClass(getApplicationContext(), Do4Activity.class);
				startActivity(Page);
				aaaa = a.play((int)(1), 1.0f, 1.0f, 1, (int)(0), 1.0f);;
			}
		});
	}
	
	private void initializeLogic() {
		a = new SoundPool((int)(2), AudioManager.STREAM_MUSIC, 0);
		aaaa = a.load(getApplicationContext(), R.raw.sod, 1);;
	}
	
}