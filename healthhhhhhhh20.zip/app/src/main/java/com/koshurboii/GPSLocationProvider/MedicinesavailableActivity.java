package com.koshurboii.GPSLocationProvider;

import android.animation.*;
import android.app.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.regex.*;
import org.json.*;

public class MedicinesavailableActivity extends AppCompatActivity {
	
	private double m1 = 0;
	
	private LinearLayout linear1;
	private LinearLayout linear6;
	private LinearLayout linear42;
	private LinearLayout linear26;
	private LinearLayout linear43;
	private LinearLayout linear45;
	private LinearLayout linear47;
	private LinearLayout linear49;
	private LinearLayout linear51;
	private LinearLayout linear53;
	private LinearLayout linear28;
	private TextView textview1;
	private TextView textview24;
	private TextView textview32;
	private ImageView imageview1;
	private LinearLayout linear33;
	private TextView textview19;
	private EditText edittext1;
	private ImageView imageview2;
	private LinearLayout linear44;
	private TextView textview27;
	private EditText edittext2;
	private ImageView imageview3;
	private LinearLayout linear46;
	private TextView textview28;
	private EditText edittext3;
	private ImageView imageview4;
	private LinearLayout linear48;
	private TextView textview29;
	private EditText edittext4;
	private ImageView imageview5;
	private LinearLayout linear50;
	private TextView textview30;
	private EditText edittext5;
	private ImageView imageview6;
	private LinearLayout linear52;
	private TextView textview31;
	private EditText edittext6;
	private ImageView imageview7;
	private LinearLayout linear54;
	private TextView textview33;
	private EditText edittext7;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.medicinesavailable);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		linear1 = findViewById(R.id.linear1);
		linear6 = findViewById(R.id.linear6);
		linear42 = findViewById(R.id.linear42);
		linear26 = findViewById(R.id.linear26);
		linear43 = findViewById(R.id.linear43);
		linear45 = findViewById(R.id.linear45);
		linear47 = findViewById(R.id.linear47);
		linear49 = findViewById(R.id.linear49);
		linear51 = findViewById(R.id.linear51);
		linear53 = findViewById(R.id.linear53);
		linear28 = findViewById(R.id.linear28);
		textview1 = findViewById(R.id.textview1);
		textview24 = findViewById(R.id.textview24);
		textview32 = findViewById(R.id.textview32);
		imageview1 = findViewById(R.id.imageview1);
		linear33 = findViewById(R.id.linear33);
		textview19 = findViewById(R.id.textview19);
		edittext1 = findViewById(R.id.edittext1);
		imageview2 = findViewById(R.id.imageview2);
		linear44 = findViewById(R.id.linear44);
		textview27 = findViewById(R.id.textview27);
		edittext2 = findViewById(R.id.edittext2);
		imageview3 = findViewById(R.id.imageview3);
		linear46 = findViewById(R.id.linear46);
		textview28 = findViewById(R.id.textview28);
		edittext3 = findViewById(R.id.edittext3);
		imageview4 = findViewById(R.id.imageview4);
		linear48 = findViewById(R.id.linear48);
		textview29 = findViewById(R.id.textview29);
		edittext4 = findViewById(R.id.edittext4);
		imageview5 = findViewById(R.id.imageview5);
		linear50 = findViewById(R.id.linear50);
		textview30 = findViewById(R.id.textview30);
		edittext5 = findViewById(R.id.edittext5);
		imageview6 = findViewById(R.id.imageview6);
		linear52 = findViewById(R.id.linear52);
		textview31 = findViewById(R.id.textview31);
		edittext6 = findViewById(R.id.edittext6);
		imageview7 = findViewById(R.id.imageview7);
		linear54 = findViewById(R.id.linear54);
		textview33 = findViewById(R.id.textview33);
		edittext7 = findViewById(R.id.edittext7);
		
		textview32.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (edittext1.getText().toString().equals("1") || (edittext1.getText().toString().equals("2") || (edittext1.getText().toString().equals("3") || (edittext1.getText().toString().equals("4") || edittext1.getText().toString().equals("5"))))) {
					linear33.setBackgroundResource(R.drawable.sjjs);
				} else {
					linear33.setBackgroundResource(R.drawable.info);
				}
				if (edittext2.getText().toString().equals("1") || (edittext2.getText().toString().equals("2") || (edittext2.getText().toString().equals("3") || (edittext2.getText().toString().equals("4") || edittext2.getText().toString().equals("5"))))) {
					linear44.setBackgroundResource(R.drawable.sjjs);
				} else {
					linear44.setBackgroundResource(R.drawable.info);
				}
				if (edittext3.getText().toString().equals("1") || (edittext3.getText().toString().equals("2") || (edittext3.getText().toString().equals("3") || (edittext3.getText().toString().equals("4") || edittext3.getText().toString().equals("5"))))) {
					linear46.setBackgroundResource(R.drawable.sjjs);
				} else {
					linear46.setBackgroundResource(R.drawable.info);
				}
				if (edittext4.getText().toString().equals("1") || (edittext4.getText().toString().equals("2") || (edittext4.getText().toString().equals("3") || (edittext4.getText().toString().equals("4") || edittext4.getText().toString().equals("5"))))) {
					linear48.setBackgroundResource(R.drawable.sjjs);
				} else {
					linear48.setBackgroundResource(R.drawable.info);
				}
				if (edittext5.getText().toString().equals("1") || (edittext5.getText().toString().equals("2") || (edittext5.getText().toString().equals("3") || (edittext5.getText().toString().equals("4") || edittext5.getText().toString().equals("5"))))) {
					linear50.setBackgroundResource(R.drawable.sjjs);
				} else {
					linear50.setBackgroundResource(R.drawable.info);
				}
				if (edittext6.getText().toString().equals("1") || (edittext6.getText().toString().equals("2") || (edittext6.getText().toString().equals("3") || (edittext6.getText().toString().equals("4") || edittext6.getText().toString().equals("5"))))) {
					linear52.setBackgroundResource(R.drawable.sjjs);
				} else {
					linear52.setBackgroundResource(R.drawable.info);
				}
				if (edittext7.getText().toString().equals("1") || (edittext7.getText().toString().equals("2") || (edittext7.getText().toString().equals("3") || (edittext7.getText().toString().equals("4") || edittext7.getText().toString().equals("5"))))) {
					linear54.setBackgroundResource(R.drawable.sjjs);
				} else {
					linear54.setBackgroundResource(R.drawable.info);
				}
			}
		});
	}
	
	private void initializeLogic() {
		if (edittext1.getText().toString().equals("1") || (edittext1.getText().toString().equals("2") || (edittext1.getText().toString().equals("3") || (edittext1.getText().toString().equals("4") || edittext1.getText().toString().equals("5"))))) {
			linear33.setBackgroundResource(R.drawable.sjjs);
		} else {
			linear33.setBackgroundResource(R.drawable.info);
		}
		if (edittext2.getText().toString().equals("1") || (edittext2.getText().toString().equals("2") || (edittext2.getText().toString().equals("3") || (edittext2.getText().toString().equals("4") || edittext2.getText().toString().equals("5"))))) {
			linear44.setBackgroundResource(R.drawable.sjjs);
		} else {
			linear44.setBackgroundResource(R.drawable.info);
		}
		if (edittext3.getText().toString().equals("1") || (edittext3.getText().toString().equals("2") || (edittext3.getText().toString().equals("3") || (edittext3.getText().toString().equals("4") || edittext3.getText().toString().equals("5"))))) {
			linear46.setBackgroundResource(R.drawable.sjjs);
		} else {
			linear46.setBackgroundResource(R.drawable.info);
		}
		if (edittext4.getText().toString().equals("1") || (edittext4.getText().toString().equals("2") || (edittext4.getText().toString().equals("3") || (edittext4.getText().toString().equals("4") || edittext4.getText().toString().equals("5"))))) {
			linear48.setBackgroundResource(R.drawable.sjjs);
		} else {
			linear48.setBackgroundResource(R.drawable.info);
		}
		if (edittext5.getText().toString().equals("1") || (edittext5.getText().toString().equals("2") || (edittext5.getText().toString().equals("3") || (edittext5.getText().toString().equals("4") || edittext5.getText().toString().equals("5"))))) {
			linear50.setBackgroundResource(R.drawable.sjjs);
		} else {
			linear50.setBackgroundResource(R.drawable.info);
		}
		if (edittext6.getText().toString().equals("1") || (edittext6.getText().toString().equals("2") || (edittext6.getText().toString().equals("3") || (edittext6.getText().toString().equals("4") || edittext6.getText().toString().equals("5"))))) {
			linear52.setBackgroundResource(R.drawable.sjjs);
		} else {
			linear52.setBackgroundResource(R.drawable.info);
		}
		if (edittext7.getText().toString().equals("1") || (edittext7.getText().toString().equals("2") || (edittext7.getText().toString().equals("3") || (edittext7.getText().toString().equals("4") || edittext7.getText().toString().equals("5"))))) {
			linear54.setBackgroundResource(R.drawable.sjjs);
		} else {
			linear54.setBackgroundResource(R.drawable.info);
		}
	}
	
	@Override
	public void onDestroy() {
		super.onDestroy();
		if (edittext1.getText().toString().equals("1") || (edittext1.getText().toString().equals("2") || (edittext1.getText().toString().equals("3") || (edittext1.getText().toString().equals("4") || edittext1.getText().toString().equals("5"))))) {
			linear33.setBackgroundResource(R.drawable.sjjs);
		} else {
			linear33.setBackgroundResource(R.drawable.info);
		}
		if (edittext2.getText().toString().equals("1") || (edittext2.getText().toString().equals("2") || (edittext2.getText().toString().equals("3") || (edittext2.getText().toString().equals("4") || edittext2.getText().toString().equals("5"))))) {
			linear44.setBackgroundResource(R.drawable.sjjs);
		} else {
			linear44.setBackgroundResource(R.drawable.info);
		}
		if (edittext3.getText().toString().equals("1") || (edittext3.getText().toString().equals("2") || (edittext3.getText().toString().equals("3") || (edittext3.getText().toString().equals("4") || edittext3.getText().toString().equals("5"))))) {
			linear46.setBackgroundResource(R.drawable.sjjs);
		} else {
			linear46.setBackgroundResource(R.drawable.info);
		}
		if (edittext4.getText().toString().equals("1") || (edittext4.getText().toString().equals("2") || (edittext4.getText().toString().equals("3") || (edittext4.getText().toString().equals("4") || edittext4.getText().toString().equals("5"))))) {
			linear48.setBackgroundResource(R.drawable.sjjs);
		} else {
			linear48.setBackgroundResource(R.drawable.info);
		}
		if (edittext5.getText().toString().equals("1") || (edittext5.getText().toString().equals("2") || (edittext5.getText().toString().equals("3") || (edittext5.getText().toString().equals("4") || edittext5.getText().toString().equals("5"))))) {
			linear50.setBackgroundResource(R.drawable.sjjs);
		} else {
			linear50.setBackgroundResource(R.drawable.info);
		}
		if (edittext6.getText().toString().equals("1") || (edittext6.getText().toString().equals("2") || (edittext6.getText().toString().equals("3") || (edittext6.getText().toString().equals("4") || edittext6.getText().toString().equals("5"))))) {
			linear52.setBackgroundResource(R.drawable.sjjs);
		} else {
			linear52.setBackgroundResource(R.drawable.info);
		}
		if (edittext7.getText().toString().equals("1") || (edittext7.getText().toString().equals("2") || (edittext7.getText().toString().equals("3") || (edittext7.getText().toString().equals("4") || edittext7.getText().toString().equals("5"))))) {
			linear54.setBackgroundResource(R.drawable.sjjs);
		} else {
			linear54.setBackgroundResource(R.drawable.info);
		}
	}
}