package com.koshurboii.GPSLocationProvider;

import android.animation.*;
import android.app.*;
import android.content.*;
import android.content.Intent;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.*;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.regex.*;
import org.json.*;

public class WebviverActivity extends AppCompatActivity {
	
	private LinearLayout linear4;
	private LinearLayout linear2;
	private WebView webview1;
	private LinearLayout linear40;
	private ImageView imageview5;
	private LinearLayout linear41;
	private TextView textview23;
	
	private Intent Page = new Intent();
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.webviver);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		linear4 = findViewById(R.id.linear4);
		linear2 = findViewById(R.id.linear2);
		webview1 = findViewById(R.id.webview1);
		webview1.getSettings().setJavaScriptEnabled(true);
		webview1.getSettings().setSupportZoom(true);
		linear40 = findViewById(R.id.linear40);
		imageview5 = findViewById(R.id.imageview5);
		linear41 = findViewById(R.id.linear41);
		textview23 = findViewById(R.id.textview23);
		
		webview1.setWebViewClient(new WebViewClient() {
			@Override
			public void onPageStarted(WebView _param1, String _param2, Bitmap _param3) {
				final String _url = _param2;
				
				super.onPageStarted(_param1, _param2, _param3);
			}
			
			@Override
			public void onPageFinished(WebView _param1, String _param2) {
				final String _url = _param2;
				
				super.onPageFinished(_param1, _param2);
			}
		});
		
		linear41.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				Page.setClass(getApplicationContext(), LlldpageActivity.class);
				startActivity(Page);
			}
		});
	}
	
	private void initializeLogic() {
		webview1.loadUrl("https://docs.google.com/forms/d/e/1FAIpQLSekzpreau9mxRH8StZqtf2M5tSg1A9NTr2GAPtu46gOD6s-cg/viewform?usp=header");
	}
	
}